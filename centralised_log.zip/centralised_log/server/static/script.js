document.addEventListener('DOMContentLoaded', function() {
    const logTable = document.getElementById('log-entries');
    const userFilter = document.getElementById('user-filter');
    const levelFilter = document.getElementById('level-filter');
    const timeFilter = document.getElementById('time-filter');
    const searchBox = document.getElementById('search-box');
    const clearFiltersBtn = document.getElementById('clear-filters');
    const refreshBtn = document.getElementById('refresh-logs');
    const exportBtn = document.getElementById('export-logs');
    const totalLogsElement = document.getElementById('total-logs');
    const connectedClientsElement = document.getElementById('connected-clients');
    const errorCountElement = document.getElementById('error-count');
    
    let allLogs = [];
    let uniqueUsers = new Set();
    let uniqueIps = new Set();
    let currentSort = { column: 'timestamp', direction: 'desc' };
    let websocket;
    
    // Initialize the dashboard
    initDashboard();
    
    function initDashboard() {
        setupWebSocket();
        setupEventListeners();
        fetchInitialLogs();
    }
    
    function setupWebSocket() {
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${wsProtocol}//${window.location.hostname}:8001`;
        
        websocket = new WebSocket(wsUrl);
        
        websocket.onopen = function() {
            console.log('Connected to WebSocket server');
        };
        
        websocket.onmessage = function(event) {
            const newLogs = JSON.parse(event.data);
            allLogs = allLogs.concat(newLogs);
            
            // Update statistics
            updateStatistics(newLogs);
            
            // Apply current filters and update table
            applyFilters();
        };
        
        websocket.onclose = function() {
            console.log('WebSocket connection closed');
            // Try to reconnect after 5 seconds
            setTimeout(setupWebSocket, 5000);
        };
    }
    
    function setupEventListeners() {
        userFilter.addEventListener('change', applyFilters);
        levelFilter.addEventListener('change', applyFilters);
        timeFilter.addEventListener('change', applyFilters);
        searchBox.addEventListener('input', applyFilters);
        
        clearFiltersBtn.addEventListener('click', function() {
            userFilter.value = '';
            levelFilter.value = '';
            timeFilter.value = 'all';
            searchBox.value = '';
            applyFilters();
        });
        
        refreshBtn.addEventListener('click', fetchInitialLogs);
        
        exportBtn.addEventListener('click', exportLogs);
        
        // Add sorting functionality to table headers
        document.querySelectorAll('th[data-sort]').forEach(header => {
            header.addEventListener('click', function() {
                const column = this.getAttribute('data-sort');
                
                // Toggle sort direction if clicking the same column
                if (currentSort.column === column) {
                    currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
                } else {
                    // Default to descending for new column
                    currentSort.column = column;
                    currentSort.direction = 'desc';
                }
                
                // Update UI to show sort indicator
                document.querySelectorAll('th i').forEach(icon => {
                    icon.className = 'fas fa-sort';
                });
                
                const icon = this.querySelector('i');
                icon.className = currentSort.direction === 'asc' 
                    ? 'fas fa-sort-up' 
                    : 'fas fa-sort-down';
                
                applyFilters();
            });
        });
    }
    
    function fetchInitialLogs() {
        fetch('/logs')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to fetch logs');
                }
                return response.json();
            })
            .then(logs => {
                allLogs = logs || [];
                updateStatistics(allLogs);
                applyFilters();
            })
            .catch(error => {
                console.error('Error fetching initial logs:', error);
            });
    }
    
    function updateStatistics(newLogs) {
        // Update total logs count
        totalLogsElement.textContent = allLogs.length;
        
        // Update error count
        const errorCount = allLogs.filter(log => log.level === 'ERROR').length;
        errorCountElement.textContent = errorCount;
        
        // Update unique users and IPs
        newLogs.forEach(log => {
            if (log.user) uniqueUsers.add(log.user);
            if (log.source_ip) uniqueIps.add(log.source_ip);
        });
        
        // Update connected clients (using unique IPs as proxy)
        connectedClientsElement.textContent = uniqueIps.size;
        
        // Update user filter options if needed
        updateUserFilterOptions();
    }
    
    function updateUserFilterOptions() {
        const currentUser = userFilter.value;
        userFilter.innerHTML = '<option value="">All Users</option>';
        
        Array.from(uniqueUsers).sort().forEach(user => {
            const option = document.createElement('option');
            option.value = user;
            option.textContent = user;
            userFilter.appendChild(option);
        });
        
        // Restore selected user if still exists
        if (currentUser && uniqueUsers.has(currentUser)) {
            userFilter.value = currentUser;
        }
    }
    
    function applyFilters() {
        const user = userFilter.value;
        const level = levelFilter.value;
        const timeRange = timeFilter.value;
        const searchTerm = searchBox.value.toLowerCase();
        
        const now = new Date();
        const filteredLogs = allLogs.filter(log => {
            // Apply user filter
            if (user && log.user !== user) return false;
            
            // Apply level filter
            if (level && log.level !== level) return false;
            
            // Apply time filter
            if (timeRange !== 'all') {
                const logTime = new Date(log.timestamp);
                let minTime;
                
                switch(timeRange) {
                    case '5m': minTime = now - 5 * 60 * 1000; break;
                    case '15m': minTime = now - 15 * 60 * 1000; break;
                    case '1h': minTime = now - 60 * 60 * 1000; break;
                    default: minTime = 0;
                }
                
                if (logTime.getTime() < minTime) return false;
            }
            
            // Apply search filter
            if (searchTerm) {
                const messageMatch = log.message.toLowerCase().includes(searchTerm);
                const userMatch = log.user.toLowerCase().includes(searchTerm);
                return messageMatch || userMatch;
            }
            
            return true;
        });
        
        // Sort logs
        const sortedLogs = sortLogs(filteredLogs, currentSort.column, currentSort.direction);
        
        // Update table
        updateLogTable(sortedLogs);
    }
    
    function sortLogs(logs, column, direction) {
        return [...logs].sort((a, b) => {
            let valA = a[column];
            let valB = b[column];
            
            // Convert timestamps to Date objects for proper sorting
            if (column === 'timestamp') {
                valA = new Date(valA);
                valB = new Date(valB);
            }
            
            // Handle undefined/null values
            if (valA === undefined || valA === null) valA = '';
            if (valB === undefined || valB === null) valB = '';
            
            if (valA < valB) return direction === 'asc' ? -1 : 1;
            if (valA > valB) return direction === 'asc' ? 1 : -1;
            return 0;
        });
    }
    
    function updateLogTable(logs) {
        logTable.innerHTML = '';
        
        logs.forEach(log => {
            const row = document.createElement('tr');
            row.classList.add(`log-${log.level}`);
            
            // Format timestamp
            const timestamp = new Date(log.timestamp);
            const formattedTimestamp = timestamp.toLocaleString();
            
            // Create cells
            const cells = [
                formattedTimestamp,
                log.user || 'N/A',
                log.level || 'N/A',
                log.message || 'N/A',
                log.source_ip || 'N/A'
            ];
            
            cells.forEach(text => {
                const cell = document.createElement('td');
                cell.textContent = text;
                row.appendChild(cell);
            });
            
            logTable.appendChild(row);
        });
    }
    
    function exportLogs() {
        const user = userFilter.value || 'all';
        const level = levelFilter.value || 'all';
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = `logs_${user}_${level}_${timestamp}.json`;
        
        const filteredLogs = allLogs.filter(log => {
            if (user !== 'all' && log.user !== user) return false;
            if (level !== 'all' && log.level !== level) return false;
            return true;
        });
        
        const dataStr = JSON.stringify(filteredLogs, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
});