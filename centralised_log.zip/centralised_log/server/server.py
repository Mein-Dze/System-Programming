import socket
import threading
import json
from datetime import datetime
from http.server import HTTPServer, SimpleHTTPRequestHandler
import os
import websockets
import asyncio
from functools import partial

class LogServer:
    def __init__(self, host='0.0.0.0', tcp_port=5000, http_port=8000, ws_port=8001):
        self.host = host
        self.tcp_port = tcp_port
        self.http_port = http_port
        self.ws_port = ws_port
        self.logs = []
        self.connected_clients = set()
        self.lock = threading.Lock()
        self.websocket_clients = set()
        
    def start_tcp_server(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((self.host, self.tcp_port))
            s.listen()
            print(f"TCP Server listening on {self.host}:{self.tcp_port}")
            
            while True:
                conn, addr = s.accept()
                client_thread = threading.Thread(target=self.handle_client, args=(conn, addr))
                client_thread.daemon = True
                client_thread.start()
                with self.lock:
                    self.connected_clients.add(conn)
    
    def handle_client(self, conn, addr):
        print(f"Client connected from {addr}")
        try:
            while True:
                data = conn.recv(1024)
                if not data:
                    break
                
                try:
                    log_entry = json.loads(data.decode())
                    log_entry['timestamp'] = datetime.now().isoformat()
                    log_entry['source_ip'] = addr[0]
                    
                    with self.lock:
                        self.logs.append(log_entry)
                    
                    print(f"Received log: {log_entry}")
                    conn.sendall(b"ACK")  # Acknowledge receipt
                    
                    # Notify WebSocket clients
                    asyncio.run_coroutine_threadsafe(self.notify_websockets(log_entry), asyncio.get_event_loop())
                except json.JSONDecodeError:
                    conn.sendall(b"ERROR: Invalid log format")
        except ConnectionResetError:
            print(f"Client {addr} disconnected")
        finally:
            with self.lock:
                if conn in self.connected_clients:
                    self.connected_clients.remove(conn)
            conn.close()
    
    async def notify_websockets(self, log_entry):
        if not self.websocket_clients:
            return
            
        message = json.dumps([log_entry])
        for client in self.websocket_clients:
            try:
                await client.send(message)
            except:
                self.websocket_clients.remove(client)
    
    async def websocket_handler(self, websocket):
        self.websocket_clients.add(websocket)
        try:
            # Send existing logs to new client
            with self.lock:
                await websocket.send(json.dumps(self.logs[-100:]))  # Send last 100 logs
            
            # Keep connection open
            while True:
                await websocket.recv()  # Just keep connection alive
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self.websocket_clients.remove(websocket)
    
    def start_http_server(self):
        os.chdir(os.path.join(os.path.dirname(__file__), 'static'))
        handler = partial(SimpleHTTPRequestHandler, directory=os.path.join(os.path.dirname(__file__), 'static'))
        server = HTTPServer((self.host, self.http_port), handler)
        print(f"HTTP Server serving at {self.host}:{self.http_port}")
        server.serve_forever()
    
    async def start_websocket_server(self):
        async with websockets.serve(self.websocket_handler, self.host, self.ws_port):
            print(f"WebSocket server started on ws://{self.host}:{self.ws_port}")
            await asyncio.Future()  # Run forever
    
    def run(self):
        # Start TCP server in a separate thread
        tcp_thread = threading.Thread(target=self.start_tcp_server)
        tcp_thread.daemon = True
        tcp_thread.start()
        
        # Start HTTP server in a separate thread
        http_thread = threading.Thread(target=self.start_http_server)
        http_thread.daemon = True
        http_thread.start()
        
        # Start WebSocket server in main thread
        asyncio.run(self.start_websocket_server())

if __name__ == "__main__":
    server = LogServer()
    server.run()