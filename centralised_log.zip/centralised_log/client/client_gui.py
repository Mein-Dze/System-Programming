import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import socket
import json
import threading
from datetime import datetime
import time
import random

class LogClientGUI:
    def __init__(self, root, server_host='localhost', server_port=5000):
        self.root = root
        self.server_host = server_host
        self.server_port = server_port
        self.connected = False
        self.socket = None
        self.reconnect_thread = None
        self.auto_log_thread = None
        self.auto_log_running = False
        
        self.setup_ui()
        self.connect_to_server()
    
    def setup_ui(self):
        self.root.title("Log Client")
        self.root.geometry("800x600")
        self.root.configure(bg='#f0f0f0')
        
        # Main container
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Connection frame
        conn_frame = ttk.LabelFrame(main_frame, text="Connection Settings", padding="10")
        conn_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(conn_frame, text="Server:").grid(row=0, column=0, sticky=tk.W, padx=5)
        self.server_entry = ttk.Entry(conn_frame, width=30)
        self.server_entry.insert(0, f"{self.server_host}:{self.server_port}")
        self.server_entry.grid(row=0, column=1, sticky=tk.EW, padx=5)
        
        ttk.Label(conn_frame, text="User ID:").grid(row=1, column=0, sticky=tk.W, padx=5)
        self.user_entry = ttk.Entry(conn_frame, width=30)
        self.user_entry.grid(row=1, column=1, sticky=tk.EW, padx=5)
        
        self.connect_btn = ttk.Button(conn_frame, text="Connect", command=self.toggle_connection)
        self.connect_btn.grid(row=2, column=0, columnspan=2, pady=5)
        
        # Log frame
        log_frame = ttk.LabelFrame(main_frame, text="Send Logs", padding="10")
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Log controls
        control_frame = ttk.Frame(log_frame)
        control_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(control_frame, text="Level:").pack(side=tk.LEFT, padx=5)
        self.level_var = tk.StringVar()
        self.level_combobox = ttk.Combobox(control_frame, textvariable=self.level_var, 
                                          values=["INFO", "WARNING", "ERROR", "DEBUG"], width=10)
        self.level_combobox.current(0)
        self.level_combobox.pack(side=tk.LEFT, padx=5)
        
        ttk.Label(control_frame, text="Message:").pack(side=tk.LEFT, padx=5)
        self.message_entry = ttk.Entry(control_frame, width=40)
        self.message_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        self.send_btn = ttk.Button(control_frame, text="Send Log", command=self.send_log, state=tk.DISABLED)
        self.send_btn.pack(side=tk.LEFT, padx=5)
        
        # Auto log controls
        auto_frame = ttk.Frame(log_frame)
        auto_frame.pack(fill=tk.X, pady=5)
        
        self.auto_log_var = tk.BooleanVar()
        self.auto_log_check = ttk.Checkbutton(auto_frame, text="Auto-generate logs", 
                                             variable=self.auto_log_var, command=self.toggle_auto_log)
        self.auto_log_check.pack(side=tk.LEFT, padx=5)
        
        ttk.Label(auto_frame, text="Interval (s):").pack(side=tk.LEFT, padx=5)
        self.interval_var = tk.DoubleVar(value=1.0)
        self.interval_spin = ttk.Spinbox(auto_frame, from_=0.1, to=10, increment=0.1, 
                                        textvariable=self.interval_var, width=5)
        self.interval_spin.pack(side=tk.LEFT, padx=5)
        
        # Log display
        self.log_display = scrolledtext.ScrolledText(log_frame, height=15, state='disabled')
        self.log_display.pack(fill=tk.BOTH, expand=True)
        
        # Status bar
        self.status_var = tk.StringVar(value="Not connected")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN)
        status_bar.pack(fill=tk.X, pady=(5,0))
        
        # Configure grid weights
        conn_frame.columnconfigure(1, weight=1)
        
        # Bind Enter key to send log
        self.message_entry.bind("<Return>", lambda e: self.send_log())
        
        # Set focus to message entry
        self.message_entry.focus_set()
    
    def toggle_connection(self):
        if self.connected:
            self.disconnect()
        else:
            self.connect_to_server()
    
    def connect_to_server(self):
        if self.connected:
            return
            
        try:
            server_str = self.server_entry.get()
            if ":" in server_str:
                host, port = server_str.split(":")
                port = int(port)
            else:
                host = server_str
                port = self.server_port
            
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((host, port))
            self.connected = True
            self.update_ui_connected()
            
            # Start thread to monitor connection
            self.reconnect_thread = threading.Thread(target=self.monitor_connection, daemon=True)
            self.reconnect_thread.start()
            
            self.add_log("System", "INFO", f"Connected to server at {host}:{port}")
            
        except Exception as e:
            messagebox.showerror("Connection Error", f"Failed to connect: {str(e)}")
            self.status_var.set(f"Connection failed: {str(e)}")
            if self.socket:
                self.socket.close()
                self.socket = None
    
    def monitor_connection(self):
        while self.connected:
            try:
                # Send a heartbeat
                self.socket.sendall(b"PING")
                data = self.socket.recv(1024)
                if not data:
                    raise ConnectionError("Server closed connection")
                time.sleep(5)
            except Exception as e:
                self.connected = False
                self.socket.close()
                self.socket = None
                self.status_var.set(f"Disconnected: {str(e)}")
                self.root.after(0, self.update_ui_disconnected)
                self.add_log("System", "ERROR", f"Connection lost: {str(e)}")
                # Try to reconnect
                time.sleep(2)
                self.root.after(0, self.connect_to_server)
                break
    
    def disconnect(self):
        if self.connected and self.socket:
            try:
                self.socket.close()
                self.add_log("System", "INFO", "Disconnected from server")
            except:
                pass
        self.connected = False
        self.socket = None
        self.update_ui_disconnected()
        self.toggle_auto_log(False)  # Stop auto logging if running
    
    def update_ui_connected(self):
        self.connect_btn.config(text="Disconnect")
        self.send_btn.config(state=tk.NORMAL)
        self.status_var.set("Connected")
        self.auto_log_check.config(state=tk.NORMAL)
    
    def update_ui_disconnected(self):
        self.connect_btn.config(text="Connect")
        self.send_btn.config(state=tk.DISABLED)
        self.status_var.set("Not connected")
        self.auto_log_check.config(state=tk.DISABLED)
    
    def send_log(self):
        if not self.connected or not self.socket:
            messagebox.showerror("Error", "Not connected to server")
            return
            
        user = self.user_entry.get().strip()
        level = self.level_var.get().strip()
        message = self.message_entry.get().strip()
        
        if not user:
            messagebox.showerror("Error", "User ID is required")
            return
            
        if not message:
            messagebox.showerror("Error", "Message is required")
            return
            
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'user': user,
            'level': level,
            'message': message
        }
        
        try:
            self.socket.sendall(json.dumps(log_entry).encode())
            response = self.socket.recv(1024)
            if response == b"ACK":
                self.message_entry.delete(0, tk.END)
                self.add_log(user, level, message)
            else:
                messagebox.showerror("Error", f"Server error: {response.decode()}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to send log: {str(e)}")
            self.disconnect()
    
    def add_log(self, user, level, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_text = f"[{timestamp}] {user} [{level}]: {message}\n"
        
        self.log_display.configure(state='normal')
        self.log_display.insert(tk.END, log_text)
        
        # Color coding
        if level == "INFO":
            color = "blue"
        elif level == "WARNING":
            color = "orange"
        elif level == "ERROR":
            color = "red"
        else:
            color = "gray"
        
        # Apply color to the new text
        start = self.log_display.index(f"end-{len(log_text)+1}c")
        end = self.log_display.index("end-1c")
        self.log_display.tag_add(level, start, end)
        self.log_display.tag_config(level, foreground=color)
        
        self.log_display.configure(state='disabled')
        self.log_display.see(tk.END)
    
    def toggle_auto_log(self, enable=None):
        if enable is None:
            enable = self.auto_log_var.get()
        
        if enable and not self.auto_log_running:
            self.auto_log_running = True
            self.auto_log_thread = threading.Thread(target=self.auto_log_worker, daemon=True)
            self.auto_log_thread.start()
            self.add_log("System", "INFO", "Auto-logging started")
        elif not enable and self.auto_log_running:
            self.auto_log_running = False
            if self.auto_log_thread:
                self.auto_log_thread.join(timeout=1)
            self.add_log("System", "INFO", "Auto-logging stopped")
    
    def auto_log_worker(self):
        messages = [
            "Application started successfully",
            "Processing request from user",
            "Database query executed",
            "Warning: Resource usage high",
            "Error: Failed to connect to database",
            "Debug: Variable value = 42",
            "System check completed",
            "New user session created",
            "Cache updated",
            "Background task running"
        ]
        
        while self.auto_log_running and self.connected:
            user = self.user_entry.get().strip() or "auto-user"
            level = random.choice(["INFO", "WARNING", "ERROR", "DEBUG"])
            message = random.choice(messages)
            
            log_entry = {
                'timestamp': datetime.now().isoformat(),
                'user': user,
                'level': level,
                'message': f"[AUTO] {message}"
            }
            
            try:
                self.socket.sendall(json.dumps(log_entry).encode())
                response = self.socket.recv(1024)
                if response == b"ACK":
                    self.root.after(0, lambda: self.add_log(user, level, f"[AUTO] {message}"))
            except:
                self.root.after(0, self.disconnect)
                break
            
            time.sleep(self.interval_var.get())

if __name__ == "__main__":
    root = tk.Tk()
    app = LogClientGUI(root)
    root.mainloop()