import socket
import json
import time
from datetime import datetime
import random

class LogClient:
    def __init__(self, server_host='localhost', server_port=5000):
        self.server_host = server_host
        self.server_port = server_port
        self.users = ['alice', 'bob', 'charlie', 'dave', 'eve']
        self.levels = ['info', 'warning', 'error', 'debug']
    
    def send_log(self, user, level, message):
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'user': user,
            'level': level,
            'message': message
        }
        
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((self.server_host, self.server_port))
            s.sendall(json.dumps(log_entry).encode())
            response = s.recv(1024)
            print(f"Server response: {response.decode()}")
    
    def generate_random_logs(self, count=10):
        for _ in range(count):
            user = random.choice(self.users)
            level = random.choice(self.levels)
            message = f"This is a {level} message from {user}"
            self.send_log(user, level, message)
            time.sleep(random.uniform(0.1, 1.0))

if __name__ == "__main__":
    client = LogClient()
    # Send some random logs for testing
    client.generate_random_logs(20)